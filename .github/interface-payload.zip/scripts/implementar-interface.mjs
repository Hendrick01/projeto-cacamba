// One-time, hash-guarded migration on the dedicated review branch only.
import fs from 'node:fs';
import crypto from 'node:crypto';
const sha = text => crypto.createHash('sha1').update(`blob ${Buffer.byteLength(text)}\0`).update(text).digest('hex');
const marker = 'interface-2026-09-07-r1';
function once(s, old, next) {
  if (s.split(old).length !== 2) throw new Error(`Expected one match: ${old.slice(0,90)}`);
  return s.replace(old, next);
}
function between(s, first, last, next) {
  const a = s.indexOf(first), b = s.indexOf(last, a + first.length);
  if (a < 0 || b < 0) throw new Error(`Missing boundaries: ${first}`);
  return s.slice(0, a) + next + s.slice(b);
}
function edit(path, expected, fn) {
  const old = fs.readFileSync(path, 'utf8');
  if (old.includes(marker)) return;
  if (sha(old) !== expected) throw new Error(`Source changed: ${path}; refusing to overwrite`);
  const next = fn(old) + (path.endsWith('.html') ? `\n<!-- ${marker} -->\n` : `\n// ${marker}\n`);
  fs.writeFileSync(path, next);
}
const home = `<section id="screen-home" class="screen">
  <div class="ui-shell">
    <header class="ui-top"><div class="ui-brand">Ca\u00e7amba</div><div class="ui-top-right"><span data-connection role="status">Conectando\u2026</span><span class="ui-version" data-interface-version>UI 07.09 / R1</span></div></header>
    <main class="ui-grid">
      <div class="ui-hero">
        <p class="ui-eyebrow">Seu lugar na mesa</p>
        <h1>Uma boa m\u00e3o.<br><em>Uma boa resenha.</em></h1>
        <p class="ui-description">Junte os amigos, escolha seu personagem e deixe as cartas contarem a hist\u00f3ria.</p>
        <div class="ui-stats"><span><strong>2\u20138</strong>jogadores</span><span><strong>7</strong>rodadas</span><span><strong>Menos pontos</strong>mais perto da vit\u00f3ria</span></div>
        <div class="ui-stage" aria-hidden="true"><div class="palco-inicio"><img id="persona-figura" alt=""></div><span class="ui-mini-card">A<br>\u2660</span><span class="ui-mini-card">7<br>\u2665</span></div>
      </div>
      <div class="ui-entry">
        <h2>Vamos jogar?</h2><p>Crie sua mesa ou entre na sala dos amigos.</p>
        <label class="field"><span>Como podemos chamar voc\u00ea?</span><input id="name-input" maxlength="16" placeholder="Seu nome" autocomplete="nickname"></label>
        <button id="btn-personagem" type="button" class="btn btn-persona"><img id="persona-cara" class="persona-cara" alt=""><span class="persona-txt"><small>Seu personagem</small><strong id="persona-nome">Gabizinsky</strong></span><span class="persona-seta">Trocar \u2197</span></button>
        <button id="btn-create" type="button" class="btn btn-primary"><span>Criar minha sala<small>Convide amigos ou adicione rob\u00f4s</small></span><span aria-hidden="true">\u2192</span></button>
        <div class="ui-divider">J\u00e1 tem um convite?</div>
        <div class="join-row"><input id="code-input" maxlength="4" aria-label="C\u00f3digo da sala, quatro letras" placeholder="C\u00d3DIGO" autocapitalize="characters" autocomplete="off"><button id="btn-join" type="button" class="btn">Entrar</button></div>
        <button id="btn-rules-home" type="button" class="btn btn-ghost">Como se joga? \u2197</button>
        <p id="home-error" class="error" role="alert" hidden></p>
      </div>
    </main>
    <footer class="ui-footer"><span>Trincas, sequ\u00eancias e boas hist\u00f3rias.</span><span>O mesmo jogo. Sua turma.</span></footer>
  </div>
</section>

`;
edit('public/index.html', '15c79d9d194eb7e6141c7c46d5ca625278a613f3', s => {
  s = once(s, '<link rel="stylesheet" href="style.css">', '<link rel="stylesheet" href="style.css">\n<link rel="stylesheet" href="interface.css">');
  s = s.replace(', user-scalable=no', '');
  return between(s, '<section id="screen-home"', '<section id="screen-avatar"', home);
});
edit('public/3d.html', '1a6da4c3cf5ea5c228cbd5f2491d4dcb42a4bdca', s => {
  s = once(s, '</head>', '<link rel="stylesheet" href="interface.css">\n</head>');
  s = once(s, '<body>', '<body class="ui-3d">');
  s = once(s, '<canvas id="cena"></canvas>', '<canvas id="cena" aria-label="Mesa de cartas em 3D"></canvas>\n<div class="ui-3d-footer"><span data-interface-version>UI 07.09 / R1</span> \u00b7 <span data-connection role="status">Conectando\u2026</span></div>');
  return s.replace(', user-scalable=no', '');
});
edit('public/client.js', '19710b922ae956bcf235cf5d29497115b2d21205', s => {
  s = once(s, "import { criaVoz } from '/voz.js';", "import { criaVoz } from '/voz.js';\nimport { layoutMao2D } from '/interface-core.js';\nimport { configuraInterface, estadoConexao, ligaControlesVoz } from '/interface.js';\nconfiguraInterface();");
  s = once(s, '    reconnectDelay = 500;', "    estadoConexao('online');\n    reconnectDelay = 500;");
  s = once(s, '  ws.onclose = (event) => {', "  ws.onclose = (event) => {\n    estadoConexao([4001,1008].includes(event.code) ? 'paused' : 'offline');");
  s = between(s, "$('btn-voz').onclick = async () => {", '// Quem est', "const controlesVoz = ligaControlesVoz(voz, { botao: $('btn-voz'), avisar: toast });\n");
  s = once(s, '      saveSession({ code: msg.code, playerId: msg.playerId, token: msg.token });', '      saveSession({ code: msg.code, playerId: msg.playerId, token: msg.token });\n      voz.reconectar?.();');
  s = once(s, '      lobby = msg;', '      lobby = msg;\n      controlesVoz.presenca(msg.players);');
  s = once(s, '      view = msg.view;', '      view = msg.view;\n      controlesVoz.presenca(view.players);');
  s = once(s, "    case 'gone':", "    case 'gone':\n      voz.desligar();");
  s = once(s, '  const fileiras = cartas.length > CARTAS_POR_FILEIRA ? 2 : 1;\n  const porFileira = Math.ceil(cartas.length / fileiras);', '  const planoMao = layoutMao2D(cartas.length, box.clientWidth || 355);\n  const fileiras = planoMao.fileiras;\n  const porFileira = planoMao.itensPorFila;');
  s = between(s, '  const folga = n > 8 ? 22 : 40;', '  cartas.forEach((card, i) => {', '  const { passo } = layoutMao2D(n, largura || 355);\n  const meio = (n - 1) / 2;\n\n');
  s = once(s, '`${passo - CARTA_LARGURA}px`', '`${passo - 60}px`');
  s = once(s, '${(i - meio) * (ABERTURA / (n - 1))}deg', '${(i - meio) * (8 / (n - 1))}deg');
  s = once(s, '    if (cartasNovas.has(card.id)) el.classList.add(\'nova\');', "    el.setAttribute('role','button'); el.tabIndex = 0;\n    el.setAttribute('aria-label', cardText(card));\n    el.setAttribute('aria-pressed', String(selected.has(card.id)));\n    el.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); el.click(); } });\n    if (cartasNovas.has(card.id)) el.classList.add('nova');");
  return s;
});
const mao3d = `function sincronizaMao() {
  if (!view?.you) return;
  const hand = maoOrdenada(), ids = new Set(hand.map(c => c.id));
  selecionadas = new Set([...selecionadas].filter(id => ids.has(id)));
  ordemManual = ordemManual.filter(id => ids.has(id));
  const cancelarVoo = mesh => { for (let i = voos.length - 1; i >= 0; i--) if (voos[i].obj === mesh) voos.splice(i, 1); };
  for (const [id, mesh] of cartasDaMao) {
    if (!ids.has(id)) { cancelarVoo(mesh); maoGrupo.remove(mesh); mesh.material.dispose(); cartasDaMao.delete(id); }
  }
  const n = hand.length;
  const plano = layoutMao3D({ quantidade:n, largura:innerWidth, altura:innerHeight, fov:camera.fov, cartaL:CARTA_L, cartaA:CARTA_A });
  layoutDaMao = plano;
  document.body.style.setProperty('--hand-height', plano.alturaMao + 'px');
  hand.forEach((card,i) => {
    let mesh = cartasDaMao.get(card.id), nova = false;
    if (!mesh) {
      mesh = new THREE.Mesh(geoCarta, materialDaCarta(card).clone());
      mesh.material.depthTest = false; mesh.material.depthWrite = false;
      mesh.userData.cardId = card.id; cartasDaMao.set(card.id,mesh); maoGrupo.add(mesh); nova = true;
    }
    cancelarVoo(mesh);
    const p = plano.posicoes[i];
    mesh.visible = true; mesh.renderOrder = 100 + i; mesh.userData.linhaMao = p.fila;
    mesh.scale.setScalar(p.escala); mesh.position.set(p.x,p.y + (selecionadas.has(card.id) ? 14 * plano.unidade : 0),p.z);
    mesh.rotation.set(0,0,p.giro);
    if (nova && entradaNaMao && !semMovimento) {
      const origem = entradaNaMao === 'meio' ? descarte.grupo.position.clone().setY(MESA_TOPO + 0.06) : topoDoMonte();
      maoGrupo.updateWorldMatrix(true,true);
      voa(mesh,noEspacoDaMao(origem),mesh.position.clone(),{dur:400,arco:0.04});
    }
  });
  entradaNaMao = null; baixadaDe = null;
  sincronizaMaos();
  if (maos.esq && maos.dir) {
    const { escala,baseY,dist,larguraLeque } = plano;
    maos.esq.visible = maos.dir.visible = n > 0;
    maos.esq.position.set(-larguraLeque * .5 - .03,baseY - .24 * escala,-dist - .03);
    maos.dir.position.set(larguraLeque * .5 + .03,baseY - .24 * escala,-dist - .03);
    maos.esq.rotation.z = -.42; maos.dir.rotation.z = .42;
    maos.esq.scale.set(-escala,escala,1); maos.dir.scale.set(escala,escala,1);
  }
}

`;
edit('public/mesa3d.js', 'fd50885cf470017d02fdc7e82a5a39afc3726a52', s => {
  s = once(s, "import { criaVoz } from '/voz.js';", "import { criaVoz } from '/voz.js';\nimport { layoutMao3D, indiceInsercao3D } from '/interface-core.js';\nimport { configuraInterface, estadoConexao, ligaControlesVoz } from '/interface.js';\nconfiguraInterface();");
  s = between(s, "document.getElementById('btn-voz')?.addEventListener('click'", 'function conecta() {', "const controlesVoz = ligaControlesVoz(voz, { botao: $('btn-voz'), avisar: texto => aviso(texto,true) });\n\n");
  s = once(s, '  ws.onopen = () => ws.send(JSON.stringify({\n    t:', "  ws.onopen = () => { estadoConexao('online'); ws.send(JSON.stringify({\n    t:");
  s = once(s, 'token: sessao.token,\n  }));', 'token: sessao.token,\n  })); };');
  s = once(s, '      view = msg.view;', '      view = msg.view;\n      controlesVoz.presenca(view.players);');
  s = once(s, "    } else if (msg.t === 'voz') {", "    } else if (msg.t === 'welcome') {\n      voz.reconectar?.();\n    } else if (msg.t === 'voz') {");
  s = once(s, "    } else if (msg.t === 'gone') {", "    } else if (msg.t === 'gone') {\n      voz.desligar();");
  s = once(s, "    voz.desligar();\n    if ([4001, 1008].includes(event.code)) {", "    estadoConexao([4001,1008].includes(event.code) ? 'paused' : 'offline');\n    if ([4001, 1008].includes(event.code)) { voz.desligar();");
  s = between(s, 'function sincronizaMao() {', '// Toque na m', mao3d);
  s = once(s, 'const hits = raycaster.intersectObjects([...cartasDaMao.values()], false);', 'const hits = raycaster.intersectObjects([...cartasDaMao.values()], false).sort((a,b) => b.object.renderOrder - a.object.renderOrder);');
  s = once(s, '  mesh.position.y = layoutDaMao.baseY + 0.14 * layoutDaMao.escala;', '  mesh.position.y = (innerHeight / 2 - e.clientY) * layoutDaMao.unidade;\n  mesh.renderOrder = 1000;');
  s = between(s, '  const antes = semEla.filter((c, i) => {', '  const ordem = semEla.map', '  const y = (innerHeight / 2 - e.clientY) * layoutDaMao.unidade;\n  const antes = indiceInsercao3D(semEla.map(c => { const m = cartasDaMao.get(c.id); return {fila:m.userData.linhaMao,x:m.position.x,y:m.position.y}; }),x,y);\n');
  s = once(s, "const barra = document.createElement('div');", "const barra = document.createElement('div');\nbarra.className = 'action-3d';");
  return s;
});
